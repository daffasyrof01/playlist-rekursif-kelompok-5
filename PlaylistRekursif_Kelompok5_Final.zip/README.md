# Playlist Rekursif Kelompok 5

Program praktikum Java untuk total durasi, reverse traversal, pencarian durasi terpanjang, dan pengukuran waktu rekursi.

## Menjalankan program

Memerlukan JDK 11 atau lebih baru; telah diuji menggunakan JDK 21. Dari folder `source`:

```powershell
javac -encoding UTF-8 PlaylistRekursif.java
java PlaylistRekursif
```

## Pengujian tambahan

```powershell
javac -encoding UTF-8 PlaylistRekursif.java PlaylistRekursifTest.java
java PlaylistRekursifTest
```

77 pemeriksaan lulus. Kasus mencakup playlist kosong, berbagai ukuran sampai 10 lagu, durasi sama, urutan traversal, konversi menit:detik, dan penolakan durasi tidak valid. Hasil uji tersimpan di `hasil/output_pengujian.txt`.

## Isi berkas

- `source/PlaylistRekursif.java`: program utama dengan koreksi return type maksimum menjadi `double` sesuai instruksi.
- `source/PlaylistRekursifTest.java`: pengujian opsional; bukan kebutuhan runtime program utama.
- `hasil/`: keluaran program aktual, grafik teoritis, screenshot, dan hasil waktu uji ulang.
- `laporan/`: laporan Word dan PDF yang mengikuti template kelompok.

File asli teman tetap tersimpan terpisah di folder lokal `source_asli`, tidak dicampur dengan source final agar tidak terjadi duplikasi class.

## Catatan hasil

Total 10 lagu adalah **44 menit 22 detik** (44,366666... menit riil); maksimum **7 menit 29 detik**. Data awal menggunakan M.SS seperti pada `PlaylistOOP.java` dari tugas sebelumnya: 4.23 berarti 4 menit 23 detik. Constructor mengonversinya menjadi menit riil (`menit + detik / 60.0`) sebelum perhitungan rekursif. Getter dan kedua fungsi numerik tetap mengembalikan `double` dalam satuan menit riil; keluaran menggunakan format menit:detik. Ketiga fungsi mempunyai waktu O(n) dan ruang stack O(n). Grafik C(n)=n+1 menunjukkan jumlah pemanggilan teoritis, bukan milidetik.

Gambar keluaran adalah transkrip dari proses Java aktual, bukan screenshot IDE. Berkas teks keluaran lengkap disertakan agar hasil dapat diperiksa dan direproduksi.

Masukan diasumsikan array tidak null, 0 <= n <= panjang array, elemen dalam prefix tidak null, dan durasi tidak negatif. Rekursi yang terlalu dalam berisiko StackOverflowError. Pengukuran sangat singkat dapat berubah akibat JIT, biaya output, dan kondisi perangkat; angka waktunya bukan bukti tunggal Big-O.

## Status distribusi

Repository publik: https://github.com/daffasyrof01/playlist-rekursif-kelompok-5 . Identitas kelompok dicantumkan sesuai persetujuan pengguna. Laporan belum dikirim ke LMS.
